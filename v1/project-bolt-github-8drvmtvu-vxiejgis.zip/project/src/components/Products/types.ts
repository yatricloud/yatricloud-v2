export interface Product {
  title: string;
  description: string;
  url: string;
  icon: React.ReactNode;
  gradient: string;
}