export interface Certification {
  name: string;
  logo: string;
  description: string;
  certCount: number;
  gradient: string;
}