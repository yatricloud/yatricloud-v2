export interface Video {
  id: string;
  title: string;
  thumbnail: string;
  author: string;
  views: string;
}