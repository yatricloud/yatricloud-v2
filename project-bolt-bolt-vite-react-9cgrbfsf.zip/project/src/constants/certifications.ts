export const CERTIFICATION_LOGOS = {
  mct: 'https://images.credly.com/size/680x680/images/fd6bb2af-2f05-4d9b-a23e-39f8e309a82d/image.png',
  mvp: 'https://images.credly.com/size/680x680/images/5c687ffb-7ab6-4fd5-bf8c-14f0178acd21/image.png',
  goldMlsa: 'https://mvp.microsoft.com/Assets/UserProfile/MSA/Badge/LevelGold.png'
} as const;