export const CONTACT_INFO = {
  phone: '+91 9724823602',
  email: 'info@yatricloud.com',
  address: {
    line1: 'E10, Green Glen Layout',
    line2: 'Outer Ring Road, Bellandur',
    city: 'Bengaluru',
    state: 'Karnataka',
    country: 'India',
    pincode: '560103'
  }
} as const;