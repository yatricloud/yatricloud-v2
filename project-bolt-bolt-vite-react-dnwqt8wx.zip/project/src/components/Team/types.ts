export interface TechnicalLeader {
  title: string;
  logo: string;
  description: string;
  gradient: string;
}