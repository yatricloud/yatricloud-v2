export const YOUTUBE_CONFIG = {
  API_KEY: "AIzaSyAzFzSc6U0T_JNWyxJqAo9AQcHbaMsAGmk",
  CHANNEL_ID: "UC0-tQsJ6S9mp2FYiaunFCYw",
  MAX_RESULTS: 6
} as const;