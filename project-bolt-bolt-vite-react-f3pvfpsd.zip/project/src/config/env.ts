// Environment variables
export const ENV = {
  SUPABASE_URL: 'https://krylibxtfjtrnmyldawb.supabase.co',
  SUPABASE_ANON_KEY: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImtyeWxpYnh0Zmp0cm5teWxkYXdiIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MzYwNzk5MzMsImV4cCI6MjA1MTY1NTkzM30.7xgXysdgZuucfQY8SmEnCctUoMmWDz-vOQDZXEzG91g'
} as const;