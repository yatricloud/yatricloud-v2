export interface YouTubeVideo {
  id: string;
  title: string;
  thumbnail: string;
  publishedAt: Date;
  description: string;
}