export const footerLinks = [
  {
    title: 'Products',
    links: [
      { label: 'Blog Yatri', url: 'https://blog.yatricloud.com' },
      { label: 'Dev Yatri', url: 'https://dev.yatricloud.com' },
      { label: 'LinkedIn Yatri', url: 'https://linkedin.yatricloud.com' },
      { label: 'Reactjs Yatri', url: 'https://reactjs.yatricloud.com' }
    ]
  }
];